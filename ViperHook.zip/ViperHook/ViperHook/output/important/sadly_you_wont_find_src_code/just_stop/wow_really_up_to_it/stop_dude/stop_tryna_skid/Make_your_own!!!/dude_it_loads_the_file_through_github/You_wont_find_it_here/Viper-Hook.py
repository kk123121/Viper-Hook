import os
import sys
import time
import shutil
import requests
import threading
import base64
from tkinter import filedialog as fd
from colorama import Fore, Style
from pystyle import Colors, Colorate, Anime, Center

banner = r"""
     /\    /\ 
    /  |  |  \
   /  /    \  \
  /  /      \  \
 /  /        \  \
/  /          \  \
\  \          /  /
 \  \        /  /
  \  \      /  /
   \  \    /  /
    \  \  /  /
     \  \/  /
      \    / 
       \  /
        \/
"""[1:]

def startup_screen():
    """Displays the startup screen and performs basic checks."""
    
    # Set title and system size (Windows-specific)
    setTitle("Texture loader and Main Startup")
    System.Size(120, 30)
    
    Anime.Fade(Center.Center(banner), Colors.blue_to_red, Colorate.Vertical, time=3)
    
    print(f"{yellow}{Style.BRIGHT}[% Viper-Hook %]{white} Loading necessary components... Please wait.")
    time.sleep(1)
    
    # Ensure output directory exists
    if not os.path.exists("output"):
        os.makedirs("output", exist_ok=True)
    
    # Remove old QR-Code directory if it exists
    if os.path.exists("output/QR-Code"):
        shutil.rmtree(f"output/QR-Code")
    
    # Check if chromedriver exists and download if missing (optional)
    os.system("""if not exist "util/chromedriver.exe" echo [#] Downloading chromedriver: """)
    os.system("""if not exist "util/chromedriver.exe" curl -#fkLo "util/chromedriver.exe" "https://github.com/AstraaDev/complement/raw/main/chromedriver.exe" """)
    
    print(f"{Fore.GREEN}[+ Viper-Hook +]{Fore.WHITE} System Size: 120x30")
    time.sleep(0.5)
    print(f"{Fore.GREEN}[+ Viper-Hook +]{Fore.WHITE} Chromedriver: OK")
    time.sleep(0.5)
    print(f"{Fore.GREEN}[+ Viper-Hook +]{Fore.WHITE} Checking for updates...")
    time.sleep(0.5)
    check_for_updates()  # Check for updates from GitHub

    print(f"{Fore.GREEN}[+ Viper-Hook +]{Fore.WHITE} Everything up to date!\n")

    input(f"{Fore.CYAN}{Style.BRIGHT}Press ENTER to continue...")

# Utility function to set window title (for Windows)
def setTitle(title):
    os.system(f"title {title}")

# Utility class to set system size (for Windows)
class System:
    @staticmethod
    def Size(width, height):
        os.system(f'mode con: cols={width} lines={height}')

# Utility to check for updates and self-update the script
def check_for_updates(current_version="1.0.0"):
    repo_owner = "kk123121"  # Replace with your GitHub username
    repo_name = "Viper-Hook"  # Replace with your GitHub repository name
    api_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/releases/latest"

    try:
        response = requests.get(api_url)
        response.raise_for_status()  # Check if the request was successful
        release_data = response.json()
        latest_version = release_data['tag_name']  # The latest release tag

        if latest_version != current_version:
            print(f"{yellow}[? Viper-Hook ?]{white} A new version is available: {latest_version}")
            print(f"{yellow}[? Viper-Hook ?]{white} You are currently using version: {current_version}")
            update_confirmation = input(f"{yellow}[? Viper-Hook ?]{white} Do you want to update to the latest version? (y/n): ")

            if update_confirmation.lower() == 'y':
                download_url = release_data['assets'][0]['browser_download_url']  # Assumes the release has an asset
                update_script(download_url)
            else:
                print(f"{green}[+ Viper-Hook +]{white} Continuing with current version.")
        else:
            print(f"{green}[+ Viper-Hook +]{white} You are using the latest version: {current_version}")
    except requests.exceptions.HTTPError as errh:
        print(f"{red}[! Viper-Hook !] HTTP Error: {errh}")
    except requests.exceptions.ConnectionError as errc:
        print(f"{red}[! Viper-Hook !] Error Connecting: {errc}")
    except requests.exceptions.Timeout as errt:
        print(f"{red}[! Viper-Hook !] Timeout Error: {errt}")
    except requests.exceptions.RequestException as err:
        print(f"{red}[! Viper-Hook !] Request Exception: {err}")

def update_script(download_url):
    """Download the latest script version and replace the current script file."""
    try:
        response = requests.get(download_url)
        response.raise_for_status()  # Check if the request was successful

        # Save the downloaded content as the current script
        script_path = os.path.realpath(__file__)  # Path to the current script file
        with open(script_path, 'wb') as script_file:
            script_file.write(response.content)

        print(f"{green}[+ Viper-Hook +]{white} Successfully updated to the latest version!")
        restart_program()

    except requests.exceptions.RequestException as err:
        print(f"{red}[! Viper-Hook !] Failed to download the update: {err}")

def restart_program():
    """Restarts the program."""
    print(f"{yellow}[? Viper-Hook ?]{white} Restarting the program to apply updates...")
    python = sys.executable
    os.execl(python, python, *sys.argv)  # Relaunch the current script

# Existing ViperHook code starts here

black = "\033[1;30m"
titletext = " [-- Viper-Hook --] Made by simple"
red = "\033[1;31m"
green = "\033[1;32m"
yellow = "\033[1;33m"
blue = "\033[1;34m"
purple = "\033[1;35m"
cyan = "\033[1;36m"
white = "\033[1;37m"
invalidurl = f"{red}[! Viper-Hook !]{white} Invalid url!"

socials = {
    "github": {"link": "https://github.com/kk123121"}
}

logo = """
        
                 ▌ ▐·▪   ▄▄▄·▄▄▄ .▄▄▄  
                ▪█·█▌██ ▐█ ▄█▀▄.▀·▀▄ █·
                ▐█▐█•▐█· ██▀·▐▀▀▪▄▐▀▀▄ 
                 ███ ▐█▌▐█▪·•▐█▄▄▌▐█•█▌
                . ▀  ▀▀▀.▀    ▀▀▀ .▀  ▀        
      >> [Webhook utils for discord created by simple.
      >> [First script after getting back into coding in py.
"""

for platform, info in socials.items():
    link = info["link"].replace("https://", "")
    logo += f"      >> [{platform.capitalize()}]: {link}\n"

logo = Center.XCenter(logo)


def choice():
    options = """
[1] Send Message            [2] Delete Webhook
[3] Rename Webhook          [4] Spam Webhook
[5] Webhook Information     [6] Log Out
[7] Change pfp
"""
    print(Colorate.Horizontal(Colors.purple_to_blue, Center.XCenter(options), 1))


def printascii():
    print(Colorate.Horizontal(Colors.purple_to_blue + Colors.blue_to_white, logo, 1))
    

def clear():
    os.system('clear' if os.name != 'nt' else 'cls')

def pause(text: str = None):
    if text:
        print(text)
    os.system('read -n 1 -s -r -p ""' if os.name != 'nt' else 'pause >nul')

def intromenu():
    clear()
    printascii()
    choice()

def changepfp(url):
    input(f"{yellow}[? Viper-Hook ?]{white} Press enter to select file or skip this to input the path/url")
    image_path = fd.askopenfilename(filetypes=[("Profile Pictures", "*.png;*.jpg;*.jpeg")])
    if image_path is None or image_path == "":
        clear()
        image_path = input(f"{yellow}[? Viper-Hook ?]{white} Path/URL to image: ")
    
    try:
        if image_path.startswith(('http://', 'https://')):
            response = requests.get(image_path)
            response.raise_for_status()
            encoded_image = base64.b64encode(response.content).decode('utf-8')
        else:
            with open(image_path, "rb") as image_file:
                encoded_image = base64.b64encode(image_file.read()).decode('utf-8')

        data = {
            "avatar": f"data:image/jpeg;base64,{encoded_image}"
        }
        print(f"{green}[+ Viper-Hook +]{white} Profile picture successfully changed!")
    
    except Exception as e:
        print(f"{red}[! Viper-Hook !]{white} Error uploading file: {e}")

if __name__ == "__main__":
    current_version = "1.0.0"  # Define your current version
    startup_screen()  # Show the startup screen
    check_for_updates(current_version)  # Check for updates after startup
    intromenu()
